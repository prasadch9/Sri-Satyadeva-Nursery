import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

export const metadata = {
  title: "Sri Satyadeva Nursery | Kadiyam",
  description: "Sri Satyadeva Nursery — plants, palms, ornamental greenery and nursery services.",
  icons: {
    icon: "branding/logo.jpg",}
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        <main>{children}</main>
        <Footer />
        <WhatsAppButton />
      </body>
    </html>
  );
}
